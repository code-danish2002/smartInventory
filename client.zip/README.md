# Smart Inventory Management System

A modern, high-performance inventory and purchase order management system built with React, Vite, and Tailwind CSS. This application provides a streamlined interface for tracking assets, managing purchase orders, and handling RMAs.

## 🚀 Overview

The Smart Inventory system is designed to provide real-time visibility into inventory levels, simplify the purchase order (PO) lifecycle, and ensure accurate tracking of items through their entire history. It features a robust hierarchical data entry system for complex POs and integrates with Keycloak for secure authentication.

## 🛠️ Technology Stack

- **Core**: [React 18](https://reactjs.org/), [Vite](https://vitejs.dev/)
- **Styling**: [Tailwind CSS 4](https://tailwindcss.com/)
- **State Management**: [React Query (TanStack)](https://tanstack.com/query/latest), React Context API
- **Data Tables**: [TanStack Table](https://tanstack.com/table/latest), [MUI X Data Grid](https://mui.com/x/react-data-grid/)
- **Forms**: [React Hook Form](https://react-hook-form.com/), [Yup](https://github.com/jquense/yup)
- **Icons & Animations**: [Lucide React](https://lucide.dev/), [Framer Motion](https://www.framer.com/motion/)
- **API Client**: [Axios](https://axios-http.com/)
- **Authentication**: [Keycloak JS](https://www.keycloak.org/)
- **PDF Generation**: [jsPDF](https://github.com/parallax/jsPDF), [pdf-lib](https://pdf-lib.js.org/)
- **Local Storage**: [Dexie.js](https://dexie.org/) (IndexedDB wrapper)

## 📁 Project Structure

```text
src/
├── api/            # API client configuration and interceptors
├── assets/         # Static assets (images, logos)
├── components/     # Main page components and high-level UI
├── config/         # Application configuration files
├── context/        # React Contexts (Auth, Theme, Render, etc.)
├── formElements/   # Reusable atomic form components
├── hooks/          # Custom React hooks
├── modals/         # Modal-based workflows (PO creation, Dispatch, etc.)
├── utils/          # Helper functions and formatting utilities
├── App.jsx         # Main application routing
└── main.jsx        # Project entry point
```

> [!NOTE]
> The `src/dump` directory contains legacy or experimental code and is excluded from the main architectural documentation.

## ⚙️ Setup & Installation

### Prerequisites

- **Node.js**: v18.x or higher
- **npm**: v9.x or higher

### Installation

1.  **Clone the repository**:
    ```bash
    git clone <repository-url>
    cd smart-inventory
    ```

2.  **Install dependencies**:
    ```bash
    npm install
    ```

3.  **Environment Variables**:
    Create a `.env` file in the root directory and add the following configuration:
    ```env
    VITE_API_BASE_URL=https://api.your-backend.com
    # Add other configuration variables as needed
    ```

### Running Locally

To start the development server:
```bash
npm run dev
```
The application will be available at `http://localhost:5173`.

## 📖 Available Scripts

- `npm run dev`: Starts the Vite development server.
- `npm run build`: Builds the production-ready application in the `dist/` folder.
- `npm run lint`: Runs ESLint to check for code quality issues.
- `npm run preview`: Previews the production build locally.

## ✨ Key Features

- **Hierarchical PO Management**: Create and manage complex purchase orders with nested items.
- **Inventory Tracking**: Real-time view of stock levels and item status.
- **RMA Workflow**: Handle returns and replacements through a dedicated module.
- **Asset History**: Full audit trail for every item in the inventory.
- **Dynamic Reporting**: Generate certificates and reports in PDF format.
- **Secure Access**: Integrated with Keycloak for enterprise-grade authentication.