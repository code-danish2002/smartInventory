import React, { useState, useMemo, useEffect } from 'react';
import { Search, ChevronLeft, ChevronRight, ArrowUp, ArrowDown, Tag, Hash, Calendar, Box, Package, Briefcase } from 'lucide-react';
import api from '../api/apiCall';
import { ContentLoading } from '../globalLoading';
import NoDataAvailable from '../utils/NoDataUi';

const StatusBadge = ({ status }) => {
    let classes = "";
    let color = "";
    switch (status) {
        case 'In Stock':
            classes = "bg-green-100 text-green-800 border-green-300";
            color = "text-green-600";
            break;
        case 'Shipped':
            classes = "bg-blue-100 text-blue-800 border-blue-300";
            color = "text-blue-600";
            break;
        case 'Dispatched':
            classes = "bg-purple-100 text-purple-800 border-purple-300";
            color = "text-purple-600";
            break;
        case 'Pending Install':
            classes = "bg-yellow-100 text-yellow-800 border-yellow-300";
            color = "text-yellow-600";
            break;
        case 'In process':
            classes = "bg-yellow-100 text-yellow-800 border-yellow-300";
            color = "text-yellow-600";
            break;
        default:
            classes = "bg-gray-100 text-gray-800 border-gray-300";
            color = "text-gray-600";
    }
    return (
        <span className={`px-3 py-1 text-sm font-semibold rounded-full border ${classes}`}>
            {status}
        </span>
    );
};

const CardDetail = ({ icon: Icon, label, value }) => (
    <div className="flex items-center space-x-2 text-gray-600 text-sm">
        <Icon className="w-4 h-4 text-blue-500 flex-shrink-0" />
        <span className="font-medium">{label}:</span>
        <span className="truncate">{value}</span>
    </div>
);

const InventoryCard = ({ item }) => {
    return (
        <div className="bg-white border border-gray-200 rounded-xl shadow-lg hover:shadow-xl transition duration-300 flex flex-col p-5">
            {/* Header: Serial Number & Status */}
            <div className="flex justify-between items-start mb-4 pb-2 border-b border-dashed border-gray-100">
                <div className="truncate flex flex-col">
                    <p className="text-xs font-semibold uppercase text-gray-500">Serial Number</p>
                    <h2 className="text-xl font-bold text-gray-900 truncate">
                        {item.item_serial_number}
                    </h2>
                </div>
                <StatusBadge status={item.item_status} />
            </div>

            {/* Core Details */}
            <div className="flex-grow space-y-3 mb-5">
                <CardDetail icon={Package} label="Item Type / Make" value={`${item.item_type_name} / ${item.item_make_name}`} />
                <CardDetail icon={Box} label="Model / Part Code" value={`${item.item_model_name} / ${item.item_part_code}`} />
                <div className="flex items-center space-x-2">
                    <CardDetail icon={Calendar} label="P.O. Date" value={new Date(item.po_date_of_issue).toLocaleDateString()} />
                    <CardDetail icon={Hash} label="Project ID" value={item.project_number} />
                </div>
                <CardDetail icon={Briefcase} label="Line Name" value={`${item.line_item_name} - ${item.description}`} />
            </div>

            {/* Footer: Less critical but useful details */}
            <div className="pt-3 border-t border-gray-100 space-y-2 text-xs">
                <div className="flex items-center justify-between text-gray-500">
                    <div className="flex items-center space-x-1">
                        <Tag className="w-3 h-3 text-gray-400" />
                        <span className="font-semibold">P.O. No:</span>
                    </div>
                    <span onClick={() => alert(`PO Number clicked ${item.po_number}`)} className="font-mono text-gray-700 cursor-pointer hover:underline hover:text-blue-600">{item.po_number}</span>
                </div>
                <div className="flex items-center justify-between text-gray-500">
                    <div className="flex items-center space-x-1">
                        <Briefcase className="w-3 h-3 text-gray-400" />
                        <span className="font-semibold">Supplier:</span>
                    </div>
                    <span className="truncate max-w-[60%] text-right">{item.firm_name}</span>
                </div>
            </div>
        </div>
    );
};




// --- Main Component ---
const MyInventory = ({ sortConfig, searchTerm }) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [page, setPage] = useState(1);
    const [limit, setLimit] = useState(12);
    const [total, setTotal] = useState(0);
    const [totalPages, setTotalPages] = useState(0);

    useEffect(() => {
        setPage(1);
    }, [searchTerm])

    const getInventory = async () => {
        setLoading(true);
        try {
            const params = {
                page: page,
                limit: limit,
            };
            if (searchTerm) {
                params.search = searchTerm;
            }
            // if (sortConfig && sortConfig.key) {
            //     params.sortBy = sortConfig.key;
            //     params.sortOrder = sortConfig.direction;
            // }

            const response = await api.get('api/pos_flat', { params });

            if (response.data && response.data.data) {
                setData(response.data.data);
                if (response.data.pagination) {
                    setLimit(response.data.pagination.limit);
                    setTotal(response.data.pagination.total);
                    setTotalPages(response.data.pagination.totalPages);
                }
            } else {
                setError('No data found');
            }
        }
        catch (error) {
            console.log(error);
            setError(error?.data?.message || 'Unable to connect to the server. Please check your connection and try again later.');
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        getInventory();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, limit, searchTerm]); // Added sortConfig to dependencies

    // Remove client-side processing as we are using server-side pagination
    let processedData = data;
    useEffect(() => {
        if (sortConfig && sortConfig.key) {
            processedData = [...data].sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
                if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        }
    }, [sortConfig])

    const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
            setPage(newPage);
        }
    };

    if (error) {
        return <NoDataAvailable title='Data Fetch Error' explanation={error} />
    }


    return (
        <div className="p-4 sm:p-6 bg-gray-50 rounded-xl shadow-inner h-full flex flex-col">
            {/* Card Grid */}
            <div className="flex-grow min-h-0 overflow-y-auto pr-2 -mr-2"> {/* Scrollable area */}
                {loading ? (
                    <ContentLoading />
                ) :
                    processedData.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6 pb-6">
                            {processedData.map((item) => (
                                <InventoryCard key={item.item_serial_number} item={item} />
                            ))}
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-48 bg-white rounded-xl border border-dashed border-gray-300">
                            <p className="text-lg text-gray-500">{error || 'No items found matching your criteria.'}</p>
                        </div>
                    )}
            </div>

            {/* Pagination Controls */}
            <div className="pt-4 flex flex-col sm:flex-row justify-end items-center border-t border-gray-200">
                <div className="flex items-center space-x-2">
                    <div className="text-sm font-medium text-gray-700 mb-2 sm:mb-0">
                        Limit:
                    </div>
                    <select
                        onChange={(e) => {
                            setLimit(parseInt(e.target.value));
                            setPage(1); // Reset to first page on limit change
                        }}
                        value={limit}
                        className="py-2 px-3 border border-gray-300 bg-white rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                    >
                        <option value="6">6</option>
                        <option value="12">12</option>
                        <option value="24">24</option>
                        <option value="48">48</option>
                    </select>
                </div>

                <div className="flex space-x-3">
                    <button
                        onClick={() => setPage(page - 1)}
                        disabled={page === 1}
                        className="flex items-center px-4 py-2 border border-gray-300 rounded-lg shadow-sm text-sm ml-2 font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition duration-150"
                    >
                        <ChevronLeft className="h-4 w-4 mr-1" /> Previous
                    </button>
                    <input type="number" value={page} min={1} max={totalPages} step={1} placeholder={page} onChange={(e) => setPage(parseInt(e.target.value))} onKeyDown={(e) => e.key === 'Enter' && handlePageChange(parseInt(e.target.value))} className="py-2 px-3 border border-gray-300 bg-white rounded-lg shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm" />
                    <span className="text-sm text-gray-500 flex items-center"> of {totalPages}</span>
                    <button
                        onClick={() => setPage(page + 1)}
                        disabled={page === totalPages || totalPages === 0}
                        className="flex items-center px-4 py-2 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition duration-150"
                    >
                        Next <ChevronRight className="h-4 w-4 ml-1" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default MyInventory;